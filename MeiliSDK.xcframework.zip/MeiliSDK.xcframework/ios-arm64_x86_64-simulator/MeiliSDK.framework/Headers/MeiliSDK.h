//
//  MeiliSDK.h
//  MeiliSDK
//
//  Created by Henrique Marques on 08/02/2024.
//

#import <Foundation/Foundation.h>

//! Project version number for MeiliSDK.
FOUNDATION_EXPORT double MeiliSDKVersionNumber;

//! Project version string for MeiliSDK.
FOUNDATION_EXPORT const unsigned char MeiliSDKVersionString[];

// In this header, you should import all the  headers of your framework using statements like #import <MeiliSDK/Header.h>


